'use strict';

var e = require('express');
var e__default = e['default'];
var ServerlessExpress = require('aws-serverless-express');
var React = require('react');
var reactDom_server = require('react-dom/server');
var tslib_1 = require('tslib');

var HelloWorld = /** @class */ (function (_super) {
    tslib_1.__extends(HelloWorld, _super);
    function HelloWorld(props) {
        var _this = _super.call(this, props) || this;
        _this.state = {
            buttonClicked: false
        };
        return _this;
    }
    HelloWorld.prototype.render = function () {
        var backgroundStyles = {
            backgroundColor: 'black',
            height: '100%',
            width: '100%'
        };
        var textStyles = {
            color: 'white',
            textAlign: 'center',
            paddingTop: '25%',
            paddingBottom: '25%'
        };
        return (React.createElement("div", { style: backgroundStyles },
            React.createElement("h1", { style: textStyles }, "hello boston!")));
    };
    return HelloWorld;
}(React.Component));

var MarkupHandler = e.Router();
MarkupHandler.get('/', function (request, response, next) {
    var html = reactDom_server.renderToString(React.createElement(HelloWorld));
    request = request;
    response.send(html);
    next();
});

var express = e__default || e;
var app = express();
app.use('/', MarkupHandler);
app.listen(3000, function () {
    console.log('Listening on port 3000:');
});
var server = ServerlessExpress.createServer(app);
exports.handler = function (event, context) {
    ServerlessExpress.proxy(server, event, context);
};
